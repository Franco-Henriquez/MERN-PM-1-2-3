const express = require("express"); //allows routing/api calls
const cors = require('cors');
const app = express();
const port = 8000
    
require("./config/mongoose.config");
    
app.use(cors(),express.json(), express.urlencoded({ extended: true }));
    
const AllProductRoutes = require("./routes/product.routes");
AllProductRoutes(app);
    
app.listen(port, () => console.log("The server is all fired up on port 8000"));