import React, {useState} from 'react';
import axios from 'axios';

const DisplayMain = (props) => {
    // return doesn't like being without atleast 1 html element
    return(
        <div>
            <h2>What can we do here..</h2>

        </div>
    )
}

export default DisplayMain;