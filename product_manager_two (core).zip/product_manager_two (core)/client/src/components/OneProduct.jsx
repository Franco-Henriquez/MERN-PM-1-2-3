import axios from 'axios';
import React, {useEffect, useState} from 'react';
import {useParams} from 'react-router-dom'

const OneProduct = (props) => {
    const {id} = useParams();
    console.log(id)
      //here we set up a constant that can store the api data
    const [product, setProduct] = useState({}); //set as empty array since our api reponse will contain a list of key pairs

  // here we set up an axios api request
    useEffect(() => {
        axios.get(`http://localhost:8000/api/products/${id}`)
            .then((response) => {
            console.log('AXIOS API RESPONSE: ',response);
            //.data.users are the object names within the array
            //data is a standard axios object
            //users is specific to what the controller in our server shows as a json response
            //res.json({ users: allDaUsers })
            setProduct(response.data.product);
            })
            .catch((err) => {
            console.log('AXIOS API ERROR: ',err);
            })
    },[])
    // return doesn't like being without atleast 1 html element
    return(
        <div>
            <h2>Product Info</h2>
            {/* <h1>Welcome to the Products Manager app</h1>
            <Link to={'/createProduct/form'}>Add a Product</Link> */}
        {
            
            <div key={product._id}>
                <p>--------------------------------------</p>
                <p>Title: {product.title}</p>
                <p>Price: {product.price}</p>
                <p>Description: {product.description}</p>
            </div>
            
        }
        </div>
    )
}

export default OneProduct;